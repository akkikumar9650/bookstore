package com.bookstore.BookStore.controller;

import com.bookstore.BookStore.Service.BookService;
import com.bookstore.BookStore.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    public ResponseEntity<Book> createdOrUpdateBook(@RequestBody Book book){
        Book savedBook = bookService.saveOrUpdateBook(book);

        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<java.awt.print.Book> getBookById(@PathVariable Long id){
        Optional<java.awt.print.Book> book = bookService.getBookById(id);

        return book.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(()->new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id){
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/search")
    public ResponseEntity<List<java.awt.print.Book>> searchBooks(@RequestParam String title){
        List<java.awt.print.Book> books = bookService.searchBooksByTitle(title);
        return new ResponseEntity<>(books,HttpStatus.OK);
    }
}


